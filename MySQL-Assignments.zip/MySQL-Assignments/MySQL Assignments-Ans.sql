use classicmodels;
/*Q1. SELECT clause with WHERE, AND, DISTINCT, Wild Card (LIKE)

a.	Fetch the employee number, first name and last name of those employees who are working as Sales Rep reporting to employee with employeenumber 1102 (Refer employee table)*/

select employeenumber,firstname,lastname from employees where jobTitle="Sales Rep" And reportsTo='1102';


/*b.	Show the unique productline values containing the word cars at the end from the products table.*/
select distinct productline from products where productLine like'%cars';

/*Q2. CASE STATEMENTS for Segmentation

. a. Using a CASE statement, segment customers into three categories based on their country:(Refer Customers table)
                        "North America" for customers from USA or Canada
                        "Europe" for customers from UK, France, or Germany
                        "Other" for all remaining countries
     Select the customerNumber, customerName, and the assigned region as "CustomerSegment".*/
     
     select customernumber,customername,case
     when country in ("USA","Canada")
     Then "North America"
     when country In ("UK","France","Germany")
     then "Europe"
     else "Other"
     end as customersegment from customers;
     
     /*Q3. Group By with Aggregation functions and Having clause, Date and Time functions

a.	Using the OrderDetails table, identify the top 10 products (by productCode) with the highest total order quantity across all orders.*/
select productCode,sum(quantityInStock) As ordernumber from products
group by productCode
order by quantityInStock DESC
limit 10;

/*b.	Company wants to analyse payment frequency by month. Extract the month name from the payment date to count the total number of payments 
for each month and include only those months with a payment count exceeding 20. Sort the results by total number of payments in descending order. 
 (Refer Payments table). */
 select strftime('%Y-%m',paymentDate) as payment_month,
 count(*) as totalPayments from payments
 group by Payment_month
 having num_payments>20
 order by num_payments DESC;
 
 
/*Q4. CONSTRAINTS: Primary, key, foreign key, Unique, check, not null, default

Create a new database named and Customers_Orders and add the following tables as per the description

a.	Create a table named Customers to store customer information. Include the following columns:

customer_id: This should be an integer set as the PRIMARY KEY and AUTO_INCREMENT.
first_name: This should be a VARCHAR(50) to store the customer's first name.
last_name: This should be a VARCHAR(50) to store the customer's last name.
email: This should be a VARCHAR(255) set as UNIQUE to ensure no duplicate email addresses exist.
phone_number: This can be a VARCHAR(20) to allow for different phone number formats.

Add a NOT NULL constraint to the first_name and last_name columns to ensure they always have a value.*/
create database Customers_Orders;
use Customers_Orders;
create table customersOrders(customer_id int primary key auto_increment,
first_name varchar(50), last_name varchar(50),email varchar(255) unique,phone_number varchar(20));

ALTER TABLE customersOrders
MODIFY first_name VARCHAR(255) NOT NULL,
MODIFY last_name VARCHAR(255) NOT NULL;
/*b.	Create a table named Orders to store information about customer orders. Include the following columns:

    	order_id: This should be an integer set as the PRIMARY KEY and AUTO_INCREMENT.
customer_id: This should be an integer referencing the customer_id in the Customers table  (FOREIGN KEY).
order_date: This should be a DATE data type to store the order date.
total_amount: This should be a DECIMAL(10,2) to store the total order amount*/

create table Orders2(orderID int Primary Key auto_increment, customerID int,
 order_Date Date,Total_Amount Decimal (10,2));

/*Constraints:
a)	Set a FOREIGN KEY constraint on customer_id to reference the Customers table.
b)	Add a CHECK constraint to ensure the total_amount is always a positive value.*/


ALTER TABLE Orders2
ADD CONSTRAINT fk_customerID
FOREIGN KEY (customerID)
REFERENCES Customers(customerID);

ALTER TABLE Orders2
ADD CONSTRAINT chk_total_amount_positive
CHECK (total_amount > 0);

/*Q5. JOINS
a. List the top 5 countries (by order count) that Classic Models ships to. (Use the Customers and Orders tables)
*/
SELECT c.country, COUNT(o.orderNumber) AS order_count
FROM Orders o
JOIN Customers c ON o.customerNumber = c.customerNumber
GROUP BY c.country
ORDER BY order_count DESC
LIMIT 5;

/*Q6. SELF JOIN
a. Create a table project with below fields.


●	EmployeeID : integer set as the PRIMARY KEY and AUTO_INCREMENT.
●	FullName: varchar(50) with no null values
●	Gender : Values should be only ‘Male’  or ‘Female’
●	ManagerID: integer */

CREATE TABLE project (
    EmployeeID INT PRIMARY KEY AUTO_INCREMENT,
    FullName VARCHAR(50) NOT NULL,
    Gender ENUM('Male', 'Female') NOT NULL,
    ManagerID INT
);

insert into project values
(1,"Pranaya","Male",3),
(2,"Priyanka","Female",1),
(3,"Preety","Female",null),
(4,"Anurag","Male",1),
(5,"Sambit","Male",1),
(6,"Rajesh","Male",3),
(7,"Hina","Female",3);

select * from project;
SELECT 
    e.ManagerName AS Employee,
    m.EmloyeeName AS Manager
FROM project;

/*Q7. DDL Commands: Create, Alter, Rename
a. Create table facility. Add the below fields into it.
●	Facility_ID
●	Name
●	State
●	Country

i) Alter the table by adding the primary key and auto increment to Facility_ID column.
ii) Add a new column city after name with data type as varchar which should not accept any null values.
*/
CREATE TABLE facility (
    Facility_ID INT,
    Name VARCHAR(100),
    State VARCHAR(50),
    Country VARCHAR(50)
);

ALTER TABLE facility
MODIFY COLUMN Facility_ID INT AUTO_INCREMENT,
ADD PRIMARY KEY (Facility_ID);

ALTER TABLE facility
ADD COLUMN city VARCHAR(100) NOT NULL AFTER Name;

/*Q8. Views in SQL
a. Create a view named product_category_sales that provides insights into sales performance by product category. This view should include the following information:
productLine: The category name of the product (from the ProductLines table).

total_sales: The total revenue generated by products within that category (calculated by summing the orderDetails.quantity * orderDetails.priceEach for each product in the category).

number_of_orders: The total number of orders containing products from that category.

(Hint: Tables to be used: Products, orders, orderdetails and productlines)
*/

CREATE VIEW product_category_sales AS
SELECT 
    pl.productLine AS productLine,
    SUM(od.quantityOrdered * od.priceEach) AS total_sales,
    COUNT(DISTINCT o.orderNumber) AS number_of_orders
FROM 
    ProductLines pl
JOIN 
    Products p ON pl.productLine = p.productLine
JOIN 
    OrderDetails od ON p.productCode = od.productCode
JOIN 
    Orders o ON od.orderNumber = o.orderNumber
GROUP BY 
    pl.productLine;

/*Q9. Stored Procedures in SQL with parameters

a. Create a stored procedure Get_country_payments which takes in year and country as inputs and gives year wise, country wise total amount as an output. Format the total amount to nearest thousand unit (K)
Tables: Customers, Payments*/

CREATE PROCEDURE `Get_Country_Payments`(In yr int, in country varchar(50))
BEGIN
	Select year(p.paymentDate)As "Year",c.Country ,concat(SUM(p.amount),' K') as TotalAmount
from customers c 
inner join payments p 
on c.customerNumber = p.customerNumber
where year(p.paymentDate) = 2004 and c.country = 'France' 
group by year(p.paymentDate),c.Country,c.customerNumber
order by year(p.paymentDate),c.country;
END;

CALL Get_country_payments(2024, 'USA');


/*Q10. Window functions - Rank, dense_rank, lead and lag

a) Using customers and orders tables, rank the customers based on their order frequency*/

SELECT 
    c.customerNumber,
    c.customer_name,
    COUNT(o.orderNumber) AS order_frequency,
    RANK() OVER (ORDER BY COUNT(o.orderNumber) DESC) As RANK
FROM 
    Customers c
LEFT JOIN 
    Orders o ON c.customerNumber = o.customerNumber
GROUP BY 
    c.customerNumber, c.customer_name
ORDER BY 
    RANK;
    
 /*b.Calculate year wise, month name wise count of orders and year over year (YoY) percentage change. Format the YoY values in no decimals and show in % sign.
Table: Orders*/

SELECT 
    EXTRACT(YEAR FROM orderDate) AS orderYear,
    TO_CHAR(orderDate, 'Month') AS monthName,
    COUNT(orderNumber) AS order_count,
    ROUND(
        (COUNT(orderNumber) - 
            COALESCE(
                LAG(COUNT(orderNumber)) OVER (PARTITION BY EXTRACT(YEAR FROM orderDate) ORDER BY EXTRACT(MONTH FROM orderDate)), 
                0
            )
        ) * 100.0 / 
            COALESCE(
                LAG(COUNT(orderNumber)) OVER (PARTITION BY EXTRACT(YEAR FROM orderDate) ORDER BY EXTRACT(MONTH FROM orderDate)), 
                1
            ), 0) AS yoy_percentage_change
FROM orders
GROUP BY 
    EXTRACT(YEAR FROM orderDate),
    TO_CHAR(orderDate, 'Month')
ORDER BY 
    orderYear, 
    EXTRACT(MONTH FROM orderDate);
   
/* Q11.Subqueries and their applications

a. Find out how many product lines are there for which the buy price value is greater than the average of buy price value. Show the output as product line and its count.*/
SELECT productLine, COUNT(*) AS productCount
FROM products
WHERE buyPrice > (SELECT AVG(buyPrice) FROM products)
GROUP BY productLine;

/*Q12. ERROR HANDLING in SQL
      Create the table Emp_EH. Below are its fields.
●	EmpID (Primary Key)
●	EmpName
●	EmailAddress*/
CREATE TABLE Emp_EH (
    EmpID INT PRIMARY KEY,           
    EmpName VARCHAR(100),           
    EmailAddress VARCHAR(100)        
);
#Create a procedure to accept the values for the columns in Emp_EH. Handle the error using exception handling concept. Show the message as “Error occurred” in case of anything wrong.

CREATE PROCEDURE InsertEmpEH(
    IN p_EmpID INT,
    IN p_EmpName VARCHAR(255),
    IN p_EmailAddress VARCHAR(255)
)
BEGIN
 
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	        SELECT 'Error occurred';
    END;
/*Create the table Emp_BIT. Add below fields in it.
●	Name
●	Occupation
●	Working_date
●	Working_hours
Insert the data as shown in below query.
INSERT INTO Emp_BIT VALUES
('Robin', 'Scientist', '2020-10-04', 12),  
('Warner', 'Engineer', '2020-10-04', 10),  
('Peter', 'Actor', '2020-10-04', 13),  
('Marco', 'Doctor', '2020-10-04', 14),  
('Brayden', 'Teacher', '2020-10-04', 12),  
('Antonio', 'Business', '2020-10-04', 11);  
 
Create before insert trigger to make sure any new value of Working_hours, if it is negative, then it should be inserted as positive.*/

CREATE TABLE Emp_BIT (
    Name VARCHAR(100) NOT NULL,
    Occupation VARCHAR(100),
    Working_date DATE,
    Working_hours INT
);

INSERT INTO Emp_BIT (Name, Occupation, Working_date, Working_hours)
VALUES
    ('Robin', 'Scientist','2020-10-04',12),
    ('Warner', 'Engineer','2020-10-04',10),
    ('Peter', 'Actor','2020-10-04', 13),
    ('Marco', 'Doctor','2020-10-04', 14),
    ('Brayden', 'Teacher','2020-10-04', 12),
    ('Antonio', 'Business','2020-10-04', 11);
    
    /*Create before insert trigger to make sure any new value of Working_hours, if it is negative, then it should be inserted as positive.*/
DELIMITER $$   
CREATE trigger trg_before_insert_emp_bit
BEFORE INSERT
ON Emp_BIT
FOR EACH ROW
BEGIN	
	set NEW.Working_hours = ABS(NEW.Working_hours);
END$$

INSERT INTO Emp_BIT (Name, Occupation, Working_date, Working_hours)
VALUES
    ('Robin', 'Scientist', '2020-10-04', -14);

select * from emp_bit;




